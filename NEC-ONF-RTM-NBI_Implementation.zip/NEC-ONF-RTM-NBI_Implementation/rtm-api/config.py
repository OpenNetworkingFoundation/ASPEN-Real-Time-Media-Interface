SECRET_KEY = 'secret'
SQLALCHEMY_DATABASE_URI = 'sqlite:///api.sqlite'
USE_TOKEN_AUTH = False
USE_RATE_LIMITS = False
